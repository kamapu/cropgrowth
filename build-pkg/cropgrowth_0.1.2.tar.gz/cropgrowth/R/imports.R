#' @importFrom methods new slot
#' @importFrom stats terms as.formula aggregate sd
#' @importFrom graphics lines polygon
NULL
