#' @title LINTUL 5 simulation results for maize in East Africa
#' 
#' @description 
#' Results of simulation for biomass growth in maize experiments in East
#' Africa.
#' 
#' @name maize_model
#' @aliases maize_model-data
#' 
#' @section Format: A data frame containing biomass growth (as g m^-2) from
#' maize experiments carried out in East Africa (Kwasunga, Tanzania) and
#' simulated with the model **LINTUL 5**.
#' The content of the columns are
#' further detailed:
#' \describe{
#'   \item{list("locality")}{Name of the experiment locality.}
#'   \item{list("crop_name")}{Name of the crop.}
#'   \item{list("treatment")}{Name of the treatment.}
#'   \item{list("current_date")}{Date of the simulation day (as [base::Date]).}
#'   \item{list("develpment_stage")}{Ordinal value for the stage of
#'     development.}
#'   \item{list("tsum")}{Temperature sum (in °C).}
#'   \item{list("yield")}{Biomass of storage organs.}
#'   \item{list("wglv")}{Biomass of green leaves.}
#'   \item{list("wgld")}{Biomass of dead leaves.}
#'   \item{list("wst")}{Biomass of stems (stover).}
#'   \item{list("wrt")}{Biomass of roots.}
#'   \item{list("lai")}{Leaf area index.}
#'   \item{list("smact")}{Volumetricsoil water content.}
#' }
#' 
#' @examples
#' data(maize_model)
#' 
#' head(maize_model)
#' tail(maize_model)
#' 
NULL
